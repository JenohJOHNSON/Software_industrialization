package fr.epita.quiz.services.business;

public class BusinessException extends Exception {

}
