package fr.epita.quiz.services.business;

public class ExamBusinessException extends BusinessException{

	
	
}
